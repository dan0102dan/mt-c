# Stale fixed-name SDK source cache rejected

The final rebuild rejected stale SDK-unpacked C/H/Makefile hashes before
compilation for the APK baseline and IPK candidate. The archive under
`package/net/mt-c/` was fresh, but `dl/mt-c-source.tar.gz` still held a prior
variant. Initial experiments had already passed this same full hash guard.

The builder now copies the fresh archive directly to the SDK download cache
immediately after `package/mt-c/clean`, verifies its SHA256, and retains the
full unpacked-source hash check before compilation. The normal recipe,
compiler flags, dependencies and SDK source preparation remain unchanged.
Fresh successful metadata records both source and download archive hashes.
These failed prepares are tooling evidence, not accepted package builds.
