# Whole-proxy object diagnostic

Pristine baseline `6a94817a` is compared with candidate `4fefbaf` using only
the original baseline `dns/proxy.o`. The new timer pool, cache and pipeline
remain. Both use the compressed upstream fixture and the same config, load
parameters, CPU affinities and client executable as the original TCP test.
Five alternating pairs, 12 seconds each, 1 second warm-up. No other known local
build/test/load/emulator job was active.

The original proxy restores both uncompressed packing under the default filter
configuration and historical question traversal logic. This is not a packing-only
switch. `summary.json` holds marginal medians/ranges; `paired-summary.json`
contains differences in repetition order. All 1,640,938 queries were valid,
with zero errors/timeouts/invalid/proxy drops.

The p99 direction remained adverse in 4/5 pairs (median difference +0.240 ms);
the observed ranges overlap. It does not establish a single cause but does
not resolve the tail concern. The final source will conservatively restrict
reusable timers/raw-response forwarding to UDP, with separate validation.

Build/link/hash proof: `../emulator-build/host-old-proxy.metadata.json`,
`host-old-proxy.build.log` and `host-old-proxy-diagnostic.json`.
