import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import tempfile
import time

repo = next(p for p in pathlib.Path(__file__).resolve().parents if (p / 'src/backend-c/Makefile').is_file())
backend = repo / 'src/backend-c'
out = repo / 'docs/c-rewrite/performance/2026-10-31/validation/udp-timer-final-fuzz'
out.mkdir(parents=True, exist_ok=True)

def hashes():
    paths = [backend / 'Makefile']
    for directory in ['src', 'include', 'tests/fuzz']:
        paths.extend(p for p in (backend / directory).rglob('*')
                     if p.is_file() and (p.suffix in ['.c', '.h'] or '/seeds/' in str(p)))
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths))}

metadata = {
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'compiler': subprocess.check_output(['clang', '--version'], text=True).splitlines()[0],
    'source_before': hashes(),
    'environment': {'ASAN_OPTIONS': 'detect_leaks=1:abort_on_error=1',
                    'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'},
    'runs_per_target': 200000,
    'scope': 'Existing DNS parse/pack/strip and fake-PTR fuzz targets; proxy transport and timer API selection are covered by focused regression tests, not these fuzz harnesses.',
    'max_len': 1600,
    'execution': 'Byte-identical copies in a private temporary executable directory; fresh seed-only corpus per variant and target.',
    'variants': [],
}

def save():
    (out / 'summary.json').write_text(json.dumps(metadata, indent=2) + '\n')

failed = False
for variant, build, kn in [('generic', 'perf-fuzz-udp-final', '0')]:
    variables = ['BUILD=' + build, 'ENTWARE_KN=' + kn, 'FUZZ_CC=clang']
    inventory = ['make', '-s', *variables, '--eval',
                 "print-fuzz-bins:\n\t@printf '%s\\n' $(FUZZ_BINS)", 'print-fuzz-bins']
    binaries = [p for p in subprocess.check_output(inventory, cwd=backend, text=True).splitlines() if pathlib.Path(p).name in ['fuzz_dns_parse', 'fuzz_fake_ptr']]
    if not binaries or any(not name.startswith('build/' + build + '/fuzz/') for name in binaries):
        raise RuntimeError('invalid fuzz inventory')
    command = ['make', '-j2', *variables, *binaries]
    entry = {'variant': variant, 'inventory_command': inventory, 'build_command': command, 'targets': []}
    metadata['variants'].append(entry)
    save()
    print('BUILD', variant, len(binaries), 'targets', flush=True)
    with (out / (variant + '-build.log')).open('w') as log:
        result = subprocess.run(command, cwd=backend, stdout=log, stderr=subprocess.STDOUT)
    entry['build_returncode'] = result.returncode
    save()
    if result.returncode:
        failed = True
        print('BUILD FAILED', variant, result.returncode, flush=True)
        continue
    with tempfile.TemporaryDirectory(prefix='mtc-fuzz-') as temp:
        temp = pathlib.Path(temp)
        for source_name in binaries:
            source = backend / source_name
            binary = temp / source.name
            shutil.copyfile(source, binary)
            binary.chmod(0o700)
            source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
            if hashlib.sha256(binary.read_bytes()).hexdigest() != source_hash:
                raise RuntimeError('executable copy mismatch')
            corpus = repo / '.build/perf/fuzz-corpus-udp-final' / variant / source.name
            corpus.mkdir(parents=True, exist_ok=True)
            if any(corpus.iterdir()):
                raise RuntimeError('fuzz corpus must start from committed seeds only')
            seeds = backend / 'tests/fuzz/seeds' / source.name
            for seed in seeds.iterdir():
                if seed.is_file():
                    shutil.copyfile(seed, corpus / seed.name)
            artifacts = repo / '.build/perf/fuzz-artifacts-udp-final' / variant / source.name
            artifacts.mkdir(parents=True, exist_ok=True)
            run_command = [str(binary), '-runs=200000', '-max_len=1600',
                           '-artifact_prefix=' + str(artifacts) + '/', str(corpus)]
            env = os.environ.copy()
            env.update(metadata['environment'])
            print('RUN', variant, source.name, flush=True)
            started = time.monotonic()
            timed_out = False
            with (out / (variant + '-' + source.name + '.log')).open('w') as log:
                try:
                    result = subprocess.run(run_command, cwd=backend, env=env,
                                            stdout=log, stderr=subprocess.STDOUT, timeout=600)
                    returncode = result.returncode
                except subprocess.TimeoutExpired:
                    timed_out = True
                    returncode = None
            text = (out / (variant + '-' + source.name + '.log')).read_text(errors='replace')
            target = {'binary': source_name, 'binary_sha256': source_hash,
                      'command': run_command, 'returncode': returncode, 'timed_out': timed_out,
                      'elapsed_seconds': time.monotonic() - started,
                      'completed_200000': 'Done 200000 runs' in text,
                      'seed': re.findall(r'INFO: Seed: (\d+)', text),
                      'final_progress': re.findall(r'^#200000\s.*$', text, flags=re.M),
                      'artifact_files': [p.name for p in artifacts.iterdir()]}
            entry['targets'].append(target)
            failed |= returncode != 0 or not target['completed_200000'] or bool(target['artifact_files'])
            save()
            print('RESULT', variant, source.name, returncode,
                  'completed=', target['completed_200000'], flush=True)
metadata['source_after'] = hashes()
metadata['source_unchanged'] = metadata['source_before'] == metadata['source_after']
metadata['passed'] = not failed and metadata['source_unchanged']
metadata['completed_target_runs'] = sum(target['completed_200000']
    for variant in metadata['variants'] for target in variant['targets'])
save()
print('DONE', metadata['passed'], metadata['completed_target_runs'], 'target runs', flush=True)
raise SystemExit(0 if metadata['passed'] else 1)
