import difflib
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile

repo = next(parent for parent in pathlib.Path(__file__).resolve().parents
            if (parent / 'src/backend-c/Makefile').is_file())
backend = repo / 'src/backend-c'
suite = backend / 'tests/differential'
golden = suite / 'golden'
out = repo / 'docs/c-rewrite/performance/2026-10-31/validation/golden'
out.mkdir(parents=True, exist_ok=True)

def hashes():
    paths = [backend / 'Makefile']
    for directory in ['src', 'include', 'tests/differential', 'spikes/regex_corpus', 'spikes/yaml_emit']:
        paths.extend(p for p in (backend / directory).rglob('*')
                     if p.is_file() and '/out/' not in str(p))
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths))}

metadata = {
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'compiler': subprocess.check_output(['gcc', '--version'], text=True).splitlines()[0],
    'source_before': hashes(),
    'scope': 'Exact pre-HTTP commands and byte comparisons from tests/differential/run_diff.sh, isolated build and output paths; existing golden files unchanged.',
    'commands': [], 'comparisons': [],
}

def save():
    (out / 'summary.json').write_text(json.dumps(metadata, indent=2) + '\n')

def run(command, label, stdin=None):
    result = subprocess.run(command, cwd=backend, input=stdin, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=180)
    metadata['commands'].append({'label': label, 'command': command, 'returncode': result.returncode})
    (out / (label + '.stderr')).write_bytes(result.stderr)
    save()
    return result

failed = False
with tempfile.TemporaryDirectory(prefix='mtc-golden-') as temp:
    temp = pathlib.Path(temp)
    for name in ['regex_corpus', 'yaml_emit']:
        target = temp / name
        command = ['sh', str(backend / 'spikes' / name / 'run.sh'), str(target)]
        result = run(command, name)
        (out / (name + '.log')).write_bytes(result.stdout)
        for item in target.iterdir():
            if item.suffix in ['.tsv', '.yaml', '.diff']:
                shutil.copyfile(item, out / (name + '-' + item.name))
        if name == 'regex_corpus':
            diff = (target / 'divergence.diff').read_text()
            normalized = ''.join(line for line in diff.splitlines(keepends=True)
                                 if line.startswith(('+', '-')) and not line.startswith(('+++', '---')))
            known = (backend / 'spikes/regex_corpus/known_divergences.tsv').read_text()
            (out / 'regex-divergence.norm').write_text(normalized)
            passed = result.returncode == 0 or (result.returncode == 1 and normalized == known)
            metadata['comparisons'].append({'label': name, 'passed': passed,
                'known_divergences_only': result.returncode == 1 and normalized == known,
                'rows': len((target / 'pcre2.tsv').read_text().splitlines())})
        else:
            passed = result.returncode == 0
            metadata['comparisons'].append({'label': name, 'passed': passed})
        failed |= not passed
        print(name, 'PASS' if passed else 'FAIL', flush=True)
        save()
    names = ['mt-configtool', 'mt-dnstool', 'mt-cachetool']
    command = ['make', '-j2', 'BUILD=perf-golden', 'CFLAGS_EXTRA=-Werror',
               *['build/perf-golden/' + name for name in names]]
    with (out / 'build.log').open('w') as log:
        result = subprocess.run(command, cwd=backend, stdout=log, stderr=subprocess.STDOUT)
    metadata['commands'].append({'label': 'build', 'command': command, 'returncode': result.returncode})
    save()
    if result.returncode:
        raise SystemExit(result.returncode)
    binaries = {}
    metadata['binaries'] = {}
    for name in names:
        source = backend / 'build/perf-golden' / name
        dest = temp / name
        shutil.copyfile(source, dest)
        dest.chmod(0o700)
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        if hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
            raise RuntimeError('executable copy mismatch')
        binaries[name] = str(dest)
        metadata['binaries'][name] = {'source': str(source), 'sha256': digest}

    def compare(command, label, expected, stdin=None):
        global failed
        result = run(command, label, stdin)
        (out / (label + '.actual')).write_bytes(result.stdout)
        expected_bytes = expected.read_bytes()
        passed = result.returncode == 0 and result.stdout == expected_bytes
        if not passed:
            delta = ''.join(difflib.unified_diff(expected_bytes.decode().splitlines(keepends=True),
                        result.stdout.decode().splitlines(keepends=True), fromfile=str(expected), tofile=label + '.actual'))
            (out / (label + '.diff')).write_text(delta)
        metadata['comparisons'].append({'label': label, 'passed': passed,
                'golden': str(expected.relative_to(repo)),
                'expected_sha256': hashlib.sha256(expected_bytes).hexdigest(),
                'actual_sha256': hashlib.sha256(result.stdout).hexdigest(),
                'rows': len(result.stdout.splitlines())})
        failed |= not passed
        save()
        print(label, 'PASS' if passed else 'FAIL', flush=True)

    for fixture in sorted((suite / 'fixtures').glob('*.yaml')):
        compare([binaries['mt-configtool'], 'resave', str(fixture), '0.99.0'],
                fixture.stem, golden / 'config-fixtures' / (fixture.stem + '.golden.yaml'))
    compare([binaries['mt-configtool'], 'resave', '/nonexistent/config.yaml', '0.99.0'],
            'missing', golden / 'config-fixtures/missing.golden.yaml')
    for mode, corpus, expected in [('match', 'match_corpus.tsv', 'match.golden.tsv'),
                                   ('subparse', 'subparse_corpus.txt', 'subparse.golden.txt')]:
        compare([binaries['mt-configtool'], mode], mode, golden / expected,
                (suite / 'corpus' / corpus).read_bytes())
    for mode in ['dump', 'stripaaaa', 'ptrcheck']:
        compare([binaries['mt-dnstool'], mode], 'dns-' + mode,
                golden / ('dns.' + mode + '.golden.txt'),
                (suite / 'corpus/dns_corpus.hex').read_bytes())
    compare([binaries['mt-cachetool']], 'cache', golden / 'cache.golden.txt',
            (suite / 'corpus/cache_script.txt').read_bytes())

    # Do not run the HTTP script against unrelated live netfilter/config state.
    result = run(['unshare', '--net', 'true'], 'http-netns-capability')
    (out / 'http-netns-capability.log').write_bytes(result.stdout + result.stderr)
    metadata['http'] = {'status': 'BLOCKED' if result.returncode else 'NOT_RUN',
        'reason': 'The host HTTP suite uses real iptables and /var paths. A private network namespace cannot be created here.' if result.returncode else 'Awaiting coordinated isolated execution.',
        'probe_returncode': result.returncode,
        'golden_sha256': hashlib.sha256((golden / 'http_contract.trace').read_bytes()).hexdigest()}
metadata['source_after'] = hashes()
metadata['source_unchanged'] = metadata['source_before'] == metadata['source_after']
metadata['non_http_passed'] = not failed and metadata['source_unchanged']
metadata['full_suite_passed'] = False
save()
print('DONE non-HTTP:', metadata['non_http_passed'], 'HTTP:', metadata['http']['status'], flush=True)
raise SystemExit(0 if metadata['non_http_passed'] else 1)
