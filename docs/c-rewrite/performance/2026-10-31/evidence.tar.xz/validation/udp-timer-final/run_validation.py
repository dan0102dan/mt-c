#!/usr/bin/env python3
"""Run the focused UDP-only timer/proxy regressions from unchanged copies."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("variant", choices=("normal", "sanitize"))
args = parser.parse_args()
out = Path(__file__).resolve().parent
repo = next(p for p in out.parents if (p / "src/backend-c/Makefile").is_file())
backend = repo / "src/backend-c"
build = "perf-udp-final" + ("-asan" if args.variant == "sanitize" else "")
names = ["test_loop", "test_loop_timer_queue", "test_dns_fastpath", "test_dns_stream"]
sources = ["src/backend-c/" + p for p in (
    "src/platform/loop.c", "include/magitrickle/loop.h", "src/dns/proxy.c",
    "tests/unit/test_loop.c", "tests/unit/test_loop_timer_queue.c",
    "tests/unit/test_dns_fastpath.c", "tests/unit/test_dns_stream.c", "Makefile",
)]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before = {p: sha(repo / p) for p in sources}
build_command = ["make", "-j4", "BUILD=" + build]
env = os.environ.copy()
if args.variant == "sanitize":
    build_command += ["OPT=-O1 -g",
                      "CFLAGS_EXTRA=-Werror -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie",
                      "LDFLAGS_EXTRA=-fsanitize=address,undefined -no-pie"]
    env["ASAN_OPTIONS"] = "detect_leaks=1:abort_on_error=1"
    env["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"
else:
    build_command += ["CFLAGS_EXTRA=-Werror"]
build_command += ["build/" + build + "/tests/" + n for n in names]
result = {
    "variant": args.variant,
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
    "compiler": subprocess.check_output(["gcc", "--version"], text=True).splitlines()[0],
    "build_command": build_command,
    "build_working_directory": str(backend),
    "execution": "Private /tmp executable copies, SHA256 checked against built binaries; backend working directory",
    "sanitizer_environment": {k: env[k] for k in ("ASAN_OPTIONS", "UBSAN_OPTIONS") if k in env},
    "source_sha256": before,
    "tests": [],
}
with tempfile.TemporaryDirectory(prefix="mtc-udp-final-") as tmp:
    for name in names:
        source = backend / "build" / build / "tests" / name
        dest = Path(tmp) / name
        digest = sha(source)
        shutil.copyfile(source, dest)
        dest.chmod(0o700)
        assert sha(dest) == digest
        log = out / (args.variant + "-" + name + ".log")
        with log.open("w") as handle:
            run = subprocess.run([str(dest)], cwd=backend, env=env,
                                 stdout=handle, stderr=subprocess.STDOUT, timeout=180)
        summary = [line for line in log.read_text().splitlines()
                   if line.startswith(("Total:", "Pass:", "Fail:", "Skip:"))]
        result["tests"].append({"name": name, "sha256": digest,
                                 "exit_code": run.returncode, "summary": summary})
        print(name, run.returncode, "; ".join(summary), flush=True)
after = {p: sha(repo / p) for p in sources}
result["source_unchanged"] = before == after
result["passed"] = result["source_unchanged"] and all(t["exit_code"] == 0 for t in result["tests"])
(out / ("summary-" + args.variant + ".json")).write_text(json.dumps(result, indent=2) + "\n")
raise SystemExit(0 if result["passed"] else 1)
