# Bounded rules reconciliation validation

Restored against baseline `6a94817a3764dbf9280a9fe657c2afd943725cb4`.
The focused suite passes **11 tests and 285,153 assertions** with warnings as
errors, and with AddressSanitizer, UndefinedBehaviorSanitizer and LeakSanitizer.
`validation.json` records source hashes, compiler, commands and scope. The
LeakSanitizer run required approved execution outside the ptrace sandbox.

The test contains the unchanged rule-major desired-list builder from that
baseline as its reference. Coverage includes 300 seeded mixed configurations,
IPv4/IPv6, aliases and cycles, expired entries, maximum remaining TTL,
permanent records, disabled groups/rules, legacy and imported wildcards,
invalid regexes and unusual namespace patterns (leading, trailing and doubled
dots, empty strings and case). Leading-dot namespace patterns retain the
single-rule matcher because the existing aggregate trie treats them differently.

An 8,197-rule fixture crosses both 4,096-rule thresholds. Call observation
checks that one temporary matcher is live at a time and it receives no more
than 4,096 rules. Empty caches compile no dynamic matchers. Result comparisons
check values and the insertion order of prefixes sharing an address; this
preserves the legacy distinction between implicit DNS hosts (`cidr=0`) and
explicit `/32` or `/128` keys, which the real kernel interprets as the same host.
Static boundaries remain in their original positions. Independent IP addresses
may be inserted in a different order within a dynamic block.

The public sync test compares fake-transport mutations and final contents with
the reference, including obsolete entries and TTL preservation. Ten injected
allocation failures exercise domain listing, matcher creation/insertion,
desired-list growth, address lookup and legacy fallback. Failures after a full
first block still produce no kernel calls, and a subsequent retry succeeds.

The 4,096-rule limit bounds the number of patterns in the temporary matcher,
not a fixed byte budget: label lengths and regex complexity still affect its
memory. The existing cache snapshot and desired lists scale with their inputs.
Wildcard/regex matching remains a linear scan within each block. Static and
leading-dot boundaries can require more passes. This suite does not establish
router speed, real kernel behavior, or complete daemon performance. No speed
claim is made from the unit-test timing fields.
