import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, tempfile, time
p = argparse.ArgumentParser()
p.add_argument('--build-dir', required=True)
p.add_argument('--out', required=True)
p.add_argument('--make-var', action='append', default=[])
p.add_argument('--jobs', default='3')
p.add_argument('--no-build', action='store_true')
p.add_argument('--repo', type=pathlib.Path)
a = p.parse_args()
repo = a.repo.resolve() if a.repo else next((d for d in pathlib.Path(__file__).resolve().parents if (d / 'src/backend-c/Makefile').is_file()), None)
if repo is None:
    p.error('specify --repo pointing to the source checkout')
backend = repo / 'src/backend-c'
out = pathlib.Path(a.out).resolve(); out.mkdir(parents=True, exist_ok=True)
variables = ['BUILD=' + a.build_dir, *a.make_var]
list_cmd = ['make', '-s', *variables, '--eval', "print-test-bins:\n\t@printf '%s\\n' $(TEST_BINS)", 'print-test-bins']
bins = subprocess.check_output(list_cmd, cwd=backend, text=True).splitlines()
if not bins or any(not b.startswith('build/' + a.build_dir + '/tests/') for b in bins):
    raise RuntimeError('invalid test inventory')
build_cmd = ['make', '-j' + a.jobs, *variables, 'all', *bins]
metadata = {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
            'build_command': build_cmd, 'test_inventory_command': list_cmd,
            'cwd': str(backend), 'binary_execution': 'Byte-identical executable copies in private /tmp directory; original backend cwd',
            'tests': []}
metadata['source_sha256'] = {str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(backend.rglob('*')) if path.is_file() and 'build' not in path.relative_to(backend).parts and (path.suffix in ('.c', '.h') or path.name == 'Makefile')}
metadata['diff_sha256'] = hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD', '--', 'src/backend-c'], cwd=repo)).hexdigest()
if not a.no_build:
    with (out / 'build.log').open('w') as f:
        build = subprocess.run(build_cmd, cwd=backend, stdout=f, stderr=subprocess.STDOUT)
    metadata['build_exit_code'] = build.returncode
    if build.returncode:
        (out / 'summary.json').write_text(json.dumps(metadata, indent=2) + '\n')
        raise SystemExit(build.returncode)
failed = False
with tempfile.TemporaryDirectory(prefix='mtc-tests-') as temp:
    for b in bins:
        source = backend / b
        dest = pathlib.Path(temp) / source.name
        shutil.copyfile(source, dest); dest.chmod(0o700)
        digest = hashlib.sha256(dest.read_bytes()).hexdigest()
        started = time.monotonic()
        logfile = out / (source.name + '.log')
        with logfile.open('w') as f:
            run = subprocess.run([str(dest)], cwd=backend, stdout=f, stderr=subprocess.STDOUT, timeout=240)
        text = logfile.read_text(errors='replace')
        result = {'path': b, 'sha256': digest, 'exit_code': run.returncode,
                  'elapsed_seconds': time.monotonic() - started,
                  'summaries': re.findall(r'(?:Total:|Pass:|FAIL|SKIP)[^\n]*', text)}
        metadata['tests'].append(result)
        failed |= run.returncode != 0
        (out / 'summary.json').write_text(json.dumps(metadata, indent=2) + '\n')
        print(source.name, run.returncode, flush=True)
metadata['passed'] = not failed
metadata['test_binaries'] = len(bins)
(out / 'summary.json').write_text(json.dumps(metadata, indent=2) + '\n')
raise SystemExit(1 if failed else 0)
